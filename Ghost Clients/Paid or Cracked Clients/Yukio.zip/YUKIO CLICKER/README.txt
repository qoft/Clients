yukio clicker ~ cracked by wolfie ~ 9/26/2020

steps:
1 -> launch YukioClicker.exe
2 -> launch any DLL injector (xenos.exe included)
3 -> inject patcher.dll into YukioClicker.exe
4 -> type in any username and password and hit enter!
5 -> profit